<header class="header price__fixed lazy">
    <div class="container">
        <div class="header__block">
            <div class="header__block-logo">
                <img src="img/@price/beautyforum/header/logo.svg" alt="">
            </div>

            <div class="header__block-link price__block">
                <a href="+74957878767" class="phone">8 495 787 8767</a>
                <a href="+74957878767" class="phone-mobile"><img src="img/@price/beautyforum/header/phone.svg" alt=""></a>
            </div>

        </div>
    </div>
</header>